CREATE PACKAGE BODY MYPACKAGE3
AS
  PROCEDURE queryFeb(num IN NUMBER, empList OUT empcursor)
  AS
    BEGIN
      OPEN
      empList FOR SELECT * FROM T_EMPLOYEE WHERE to_char(HIRE_DATE,'mm')=num;
    END queryFeb;
END MYPACKAGE3;
/

