CREATE PACKAGE MYPACKAGE7
  AS
  TYPE empcursor IS REF CURSOR ;
  PROCEDURE queryAll(empList OUT empcursor);
  END MYPACKAGE7;
/

CREATE PACKAGE BODY MYPACKAGE7
    AS
    PROCEDURE queryAll(empList OUT empcursor)
    AS
      BEGIN
        OPEN
        empList FOR SELECT E_NAME, HIRE_DATE,
          trunc(to_char(months_between(sysdate,HIRE_DATE))/12),
          trunc(mod((sysdate-HIRE_DATE),365)/30),
          trunc(mod(mod((sysdate-HIRE_DATE),365),30))
          FROM T_EMPLOYEE;
      END queryAll;
    END MYPACKAGE7;
/

