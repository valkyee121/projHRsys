CREATE TRIGGER TRIG_RECO_INSERT_FORBID
  BEFORE INSERT
  ON T_HRSYS_RECO
  FOR EACH ROW
  DECLARE
    v_count NUMBER(2);
  BEGIN
    SELECT count(*) INTO v_count FROM T_HRSYS_RECO WHERE RECO_SAL_ID=:NEW.RECO_SAL_ID;
    IF (v_count>0) THEN
      raise_application_error(-20017,'无法多次申请复议');
    END IF;
  END;
/

