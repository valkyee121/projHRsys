CREATE PACKAGE BODY MYPACKAGE6
AS
  PROCEDURE queryByDaySal(empList OUT empcursor)
  AS
    BEGIN
      OPEN
      empList FOR SELECT E_NAME, round(E_SAL/30) FROM T_EMPLOYEE ;
    END queryByDaySal;
END MYPACKAGE6;
/

