CREATE PROCEDURE register(uTele IN NUMBER, uid OUT NUMBER)
  AS
  BEGIN
    SELECT "u_id" INTO uid FROM "t_hrsys_user" WHERE "u_teleNum"=uTele;
  END;
/

