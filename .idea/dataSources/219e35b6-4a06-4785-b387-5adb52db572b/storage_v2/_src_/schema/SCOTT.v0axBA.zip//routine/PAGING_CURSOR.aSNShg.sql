CREATE PROCEDURE paging_cursor(v_in_table IN VARCHAR2, v_in_pagesize IN NUMBER,v_in_pagenow IN NUMBER,
    v_out_result OUT pagingPackage.paging_cursor, v_out_rows OUT NUMBER, v_out_pagecount OUT NUMBER) IS
    v_sql VARCHAR2(4000);
    v_sql_select VARCHAR2(4000);
    v_start NUMBER;
    v_end NUMBER;
    BEGIN
      v_start:=v_in_pagesize*(v_in_pagenow-1)+1;
      v_end:=v_in_pagesize*v_in_pagenow;
      v_sql:='t2.* from (select t1.*, rownum rn from ' ||
             '(select * from '||v_in_table||') t1 ' ||
             'where rownum<='||v_end||') t2 ' ||
             'where rn>='||v_start;
      OPEN v_out_result FOR v_sql;
      /*查询到的记录总数*/
      v_sql_select:='select count(*) from '||v_in_table;
      EXECUTE IMMEDIATE v_sql_select INTO v_out_rows;
      /*统计记录页数*/
      IF mod(v_out_rows,v_in_pagesize)=0 THEN
        v_out_pagecount:=v_out_rows/v_in_pagesize;
        ELSE
        v_out_pagecount:=v_out_rows/v_in_pagesize+1;
      END IF;
      CLOSE v_out_result;
    END;
/

