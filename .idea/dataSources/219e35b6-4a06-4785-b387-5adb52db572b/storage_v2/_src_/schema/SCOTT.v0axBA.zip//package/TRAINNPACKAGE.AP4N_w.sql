CREATE PACKAGE trainnPackage IS
  TYPE tr_cursor IS REF CURSOR ;
  END ;
/

