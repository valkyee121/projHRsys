CREATE TRIGGER TRIG_USER_INSERT_CHECK
  BEFORE INSERT
  ON T_HRSYS_USER
  FOR EACH ROW
  DECLARE
    v_count NUMBER(5);
    BEGIN
    SELECT count(*) INTO v_count FROM T_HRSYS_USER WHERE U_EMAIL=:NEW.U_EMAIL;
    IF (v_count>0) THEN
      raise_application_error(-20000,'用户已存在，无法插入');
      END IF ;
  END;
/

