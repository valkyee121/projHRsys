CREATE PROCEDURE TDINTER_INSERT (trID IN NUMBER, emplist IN tdtable)
  IS
  BEGIN
    FOR i IN 1..emplist.COUNT LOOP
      INSERT INTO T_HRSYS_TDINTER (TD_EMP_ID, TD_TR_ID) VALUES
        (
          emplist(i).a,
          trID
        );
    END LOOP;
  END;
/

