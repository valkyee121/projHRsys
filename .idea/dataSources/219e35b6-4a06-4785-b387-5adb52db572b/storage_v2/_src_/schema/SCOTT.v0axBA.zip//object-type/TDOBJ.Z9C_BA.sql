CREATE TYPE tdobj AS OBJECT (
  a NUMBER(10)  
)
/

