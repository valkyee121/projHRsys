CREATE PROCEDURE insertEmp(eno IN NUMBER, ename IN VARCHAR2, ejob IN VARCHAR2, emgr IN NUMBER,
esal IN NUMBER, ecomm IN NUMBER, edept IN NUMBER)
  AS
  peno T_EMPLOYEE.E_NO%TYPE ;
  BEGIN
      INSERT INTO T_EMPLOYEE(E_NO,E_NAME,E_JOB,E_MGR,HIRE_DATE,E_SAL,E_COMM,DEP_NO) VALUES (eno,ename,ejob,emgr,to_date(sysdate),esal,ecomm,edept);
  END;
/

