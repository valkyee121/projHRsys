CREATE PACKAGE pagingPackage IS
  TYPE paging_cursor is REF CURSOR ;
END ;
/

