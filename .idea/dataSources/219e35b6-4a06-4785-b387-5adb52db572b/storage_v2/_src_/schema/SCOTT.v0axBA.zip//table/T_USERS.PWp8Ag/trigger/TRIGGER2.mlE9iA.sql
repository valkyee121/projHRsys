CREATE TRIGGER TRIGGER2
  BEFORE INSERT OR UPDATE
  ON T_USERS
  BEGIN
    IF to_char(sysdate,'day') IN ('星期三','星期六','星期日') OR
      to_char(sysdate,'hh24') NOT BETWEEN '10' AND '18' THEN
      raise_application_error(-20001,'非工作时间禁止操作');
    END IF;
  END;
/

