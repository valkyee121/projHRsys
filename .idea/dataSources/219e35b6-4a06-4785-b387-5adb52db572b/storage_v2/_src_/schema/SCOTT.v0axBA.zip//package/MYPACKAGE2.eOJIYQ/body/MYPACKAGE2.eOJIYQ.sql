CREATE PACKAGE BODY MYPACKAGE2
AS
  PROCEDURE queryEarly(num IN NUMBER, empList OUT empcursor)
  AS
    BEGIN
      OPEN
      empList FOR SELECT * FROM T_EMPLOYEE WHERE months_between(sysdate,HIRE_DATE)/12 >=num;
    END queryEarly;
END MYPACKAGE2;
/

