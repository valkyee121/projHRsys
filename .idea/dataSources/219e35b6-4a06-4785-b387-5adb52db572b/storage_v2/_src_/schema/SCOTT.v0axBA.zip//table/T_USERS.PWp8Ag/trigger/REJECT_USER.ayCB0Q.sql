CREATE TRIGGER REJECT_USER
  BEFORE INSERT
  ON T_USERS
  FOR EACH ROW
  DECLARE
    BEGIN
    IF :NEW.U_NAME LIKE 'i%' THEN
      raise_application_error(-20002,'员工姓名不能以i开头');
    END IF;
  END;
/

