CREATE TRIGGER TRIG_JOB_INSERT_FORBID
  BEFORE INSERT
  ON T_HRSYS_JOB
  FOR EACH ROW
  DECLARE
    v_count NUMBER(2);
  BEGIN
    SELECT count(*) INTO v_count FROM T_HRSYS_JOB WHERE JOB_NAME=:NEW.JOB_NAME;
    IF (v_count>0) THEN
      raise_application_error(-20007,'职位已存在');
    END IF;
  END;
/

